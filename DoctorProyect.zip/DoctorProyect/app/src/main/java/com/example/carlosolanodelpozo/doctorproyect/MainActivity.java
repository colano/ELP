package com.example.carlosolanodelpozo.doctorproyect;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
Button button_sigin;
EditText user_text, pass_text;
    connecMysql connection;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user_text = (EditText) findViewById(R.id.text_username);
        pass_text = (EditText) findViewById(R.id.text_password);
        button_sigin = (Button) findViewById(R.id.button_login);
        button_sigin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        int type, code;
                        connection = new connecMysql();
                        connection.connect();
                        connection.login(user_text.getText().toString(),pass_text.getText().toString());
                        code = connection.getCode();
                        type = connection.getType();
                        if (type == 0){
                            Intent doctorInt = new Intent(getApplicationContext(), DoctorActivity.class);
                            connection.close();
                            doctorInt.putExtra("code", code);
                            startActivity(doctorInt);
                        } else if (type==1){
                            Intent patientInt = new Intent(getApplicationContext(), PatientActivity.class);
                            connection.close();
                            patientInt.putExtra("code", code);
                            startActivity(patientInt);
                        } else {
                            AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                            dialog.setTitle("¡Error en inicio de sesión!");
                            dialog.setCancelable(true);
                            dialog.setMessage("Usuario o contraseña incorrecta");

                            dialog.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                }
                            });
                            dialog.show();
                        }

                    }
                };

                thread.start();

            }
        });
    }
}
