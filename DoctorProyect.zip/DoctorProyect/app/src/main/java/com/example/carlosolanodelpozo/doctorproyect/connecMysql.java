package com.example.carlosolanodelpozo.doctorproyect;

import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by carlosolanodelpozo on 8/2/18.
 */

public class connecMysql {

    Connection DbConn;
    int type,code;
    connecMysql (){

    }
    void connect() {

        try {
            String url = "jdbc:mysql://192.168.49.1:3306/doctorProyect_dB";
            String username = "carlos";
            String password = "carlos";
            Class.forName("com.mysql.jdbc.Driver").newInstance();

            DbConn = DriverManager.getConnection(url,username,password);
            Log.w("Connection", "open");
        } catch (Exception e) {
            Log.w("Error connection", "" + e.getMessage());
        }
    }

    void login(String user, String pass){
        Statement stmt = null;
        ResultSet reset = null;
        String query = "select type, id from users where user='"+user+"' and pass='"+pass+"'";
        type = 2;
        code = 0;
        try {
            stmt = DbConn.createStatement();

            reset = stmt.executeQuery(query);
            while (reset.next()) {
                 type = reset.getInt(1);
                 code = reset.getInt(2);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ResultSet doQuery(String query){
        Statement stmt = null;
        ResultSet result = null;
        try {
            stmt = DbConn.createStatement();
            result = stmt.executeQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public int getType(){
        return type;
    }
    public int getCode(){
        return code;
    }

    public void close(){
        try {
            DbConn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
