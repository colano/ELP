package com.example.carlosolanodelpozo.doctorproyect;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DoctorActivity extends AppCompatActivity {
    int code;
    connecMysql connection;

    ListView listusers;
    List<String> users= new ArrayList<String>();
    List<Integer> ids= new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        code = getIntent().getExtras().getInt("code");
        setContentView(R.layout.main_doctor);
        listusers =(ListView) findViewById(R.id.listView);
        final ArrayAdapter<String> usersadapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, users);
        listusers.setAdapter(usersadapter);
        listusers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                final Integer code = ids.get(i);
                AlertDialog.Builder dialog = new AlertDialog.Builder(DoctorActivity.this);
                dialog.setTitle(users.get(i));
                dialog.setCancelable(true);
                dialog.setMessage("hola que desea ver/modificar de este paciente?");

                dialog.setPositiveButton("Medicamentos", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent listInt = new Intent(getApplicationContext(), ListActivity.class);
                        connection.close();
                        listInt.putExtra("code", 0);
                        listInt.putExtra("id", code);
                        startActivity(listInt);
                    }
                });

                dialog.setNegativeButton("Ejercicios", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent listInt = new Intent(getApplicationContext(), ListActivity.class);
                        connection.close();
                        listInt.putExtra("code", 1);
                        listInt.putExtra("id", code);
                        startActivity(listInt);
                    }
                });
                dialog.show();
            }
        });

        Thread thread = new Thread() {
            @Override
            public void run() {
                connection =  new connecMysql();
                connection.connect();
                ResultSet result = connection.doQuery("SELECT id, user FROM rel_pm INNER JOIN users ON id=id_patient WHERE id_med="+code);
                try {
                    int i = 0;
                    while (result.next()){
                        ids.add(result.getInt(1));
                        users.add(result.getString(2));
                        i++;
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        };

        thread.start();

    }
}
