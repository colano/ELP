package com.example.carlosolanodelpozo.doctorproyect;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientActivity extends AppCompatActivity {
    int code;
    connecMysql connection;
    ListView listvmedi, listvexer;
    List<String> medicines= new ArrayList<String>();
    List<String> exercices= new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_patient);
        code = getIntent().getExtras().getInt("code");
        listvmedi =(ListView) findViewById(R.id.listView2);
        listvexer =(ListView) findViewById(R.id.listView3);
        final ArrayAdapter<String> medadapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, medicines);
        listvmedi.setAdapter(medadapter);
        listvmedi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(PatientActivity.this);
                dialog.setTitle("Medicamento:");
                dialog.setCancelable(true);
                dialog.setMessage(medicines.get(i));
                dialog.show();
            }
        });

        final ArrayAdapter<String> exeradapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, exercices);
        listvexer.setAdapter(exeradapter);
        listvexer.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(PatientActivity.this);
                dialog.setTitle("Ejercicios:");
                dialog.setCancelable(true);
                dialog.setMessage(exercices.get(i));
                dialog.show();
            }
        });

        Thread thread = new Thread() {
            @Override
            public void run() {
                connection =  new connecMysql();
                connection.connect();
                ResultSet result = connection.doQuery("SELECT * FROM medicines WHERE id_client="+code);
                try {
                    while (result.next()){
                        medicines.add(result.getString(3));
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                ResultSet result2 = connection.doQuery("SELECT * FROM exercices WHERE id_client="+code);
                try {
                    while (result2.next()){
                        exercices.add(result2.getString(3));
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                connection.close();
            }
        };
        thread.start();
    }
}
