package com.example.carlosolanodelpozo.doctorproyect;


import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ListActivity extends AppCompatActivity {
    connecMysql connection;
    int type;
    int num;
    int code;
    ListView list;
    List<String> medicines_exercices= new ArrayList<String>();
    List<Integer> ids= new ArrayList<Integer>();
    Button button_add;
    EditText description;
    EditText date_text;
    ArrayAdapter<String> listadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        type = getIntent().getExtras().getInt("code");
        code = getIntent().getExtras().getInt("id");
        listadapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, medicines_exercices);

        date_text = (EditText) findViewById(R.id.date);
        description = (EditText) findViewById(R.id.description);
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        final String today = dateFormat.format(date);
        setContentView(R.layout.activity_list);

        list =(ListView) findViewById(R.id.listView2);


        final Thread thread2 = new Thread() {
            @Override
            public void run() {
                connection =  new connecMysql();
                connection.connect();
                ResultSet result;
                if (type == 0) {
                    result = connection.doQuery("SELECT * FROM medicines WHERE id_client="+code);
                } else {
                    result = connection.doQuery("SELECT * FROM exercices WHERE id_client="+code);
                }
                try {
                    while (result.next()){
                        medicines_exercices.add(result.getString(3));
                        ids.add(result.getInt(1));
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        };

        thread2.start();

        final Thread thread3 = new Thread() {
            @Override
            public void run() {
                connection =  new connecMysql();
                connection.connect();

                String query;
                if (type==0){
                    query = "delete from medicines where id="+ids.get(num)+" and id_client="+code;
                } else {
                    query = "delete from exercices where id="+ids.get(num)+" and id_client="+code;
                }
                connection.doQuery(query);
                medicines_exercices.remove(num);
            }
        };

        list.setAdapter(listadapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(ListActivity.this);
                dialog.setTitle("¿Desea borrar esta entrada?");
                dialog.setCancelable(true);
                dialog.setMessage(medicines_exercices.get(i));
                 num = i;
                dialog.setPositiveButton("Borrar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        thread3.start();
                        listadapter.notifyDataSetChanged();
                    }
                });
                dialog.show();
            }
        });



    }
}
