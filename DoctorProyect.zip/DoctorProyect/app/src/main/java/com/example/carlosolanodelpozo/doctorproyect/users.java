package com.example.carlosolanodelpozo.doctorproyect;

/**
 * Created by carlosolanodelpozo on 14/2/18.
 */

public class users {
    private int id;
    private String name;
    public users (){

    }
    public users(int id, String name){
        this.id = id;
        this.name = name;
    }

    public int getid(){
        return id;
    }
    public String getname(){
        return name;
    }
}
